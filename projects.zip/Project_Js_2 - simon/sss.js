let startBtn = document.getElementById('startGameBtn');



let playerScore = 0;
let arrNum = [2, 3, 2, 1, 1]; 
let userTurn = false;

//! פונקציה שמאפסת את הניקוד והמערך לתחילת המשחק
let initGame = () => {
    // arrNum = [];
    playerScore = 0;
}

function startTheGame () {
    startBtn.style.display = "none";
    gameControler();
}

//! פונקציה שיוצרת מספר רנדומלי בין 1 ל4
let createStep = () => {
    let randomNum = Math.floor(Math.random() * 4) + 1;
    return randomNum;
}

//! פונקציה שתשלוט במהלך של התור של המחשב
async function gameControler () {
    userTurn = false;
    let giveRandomNum = createStep();
    arrNum.push(giveRandomNum);
    console.log(arrNum);
    await pcTurnNow();
    userTurn = true;
    console.log(userTurn);
}

async function pcTurnNow () {
    let someCounter = 0;
    for (let i of arrNum) {
        if (someCounter !== arrNum.length) {
            if (i == 1) {
                console.log("red");
                await lightUpButton("red");
            }
            if (i == 2) {
                console.log("green");
                await lightUpButton("green");
            }
            if (i == 3) {
                console.log("yellow");
                await lightUpButton("yellow");
            }
            if (i == 4) {
                console.log("blue");
                await lightUpButton("blue");
            }
            someCounter++;
        } 
    }
}

function lightUpButton(buttonId) {
    const buttonElement = document.getElementById(buttonId);
    buttonElement.classList.add(`${buttonId}On`);
    return new Promise(resolve => {
        setTimeout(() => {
            buttonElement.classList.remove(`${buttonId}On`);
            resolve();
        }, 150);
    });
}

function userClickOnColor(event) {
    if (userTurn) {
        if (event.target.id === "red") {
            return TheUserTurn(1);
        }
        if (event.target.id === "green") {
            return TheUserTurn(2);
        }
        if (event.target.id === "yellow") {
            return TheUserTurn(3);
        }
        if (event.target.id === "blue") {
            return TheUserTurn(4);
        }
    }
}

function TheUserTurn(guess) {
    if (userTurn) {
        if (guessTrueOrFalse(guess, playerScore)) {
            playerScore++;
            console.log("correct");
        } else {
            console.log("Incorrect");
        }
    }
}

//! פונקציה שבודקת אם הלחיצה של המשתמש אכן תואמת למקום במערך
function guessTrueOrFalse(color, theIndex) {
    return color === arrNum[theIndex];
}

initGame();
startBtn.addEventListener('click', startTheGame);
document.getElementById('red').addEventListener('click', userClickOnColor);
document.getElementById('green').addEventListener('click', userClickOnColor);
document.getElementById('yellow').addEventListener('click', userClickOnColor);
document.getElementById('blue').addEventListener('click', userClickOnColor);
