let startBtn = document.getElementById('startGameBtn');
let messageDiv = document.getElementById('theMessage');

let playerScore = 0;
let arrNum = []; 
let userTurn = false;
let highScore = 0;
let gameScore = 0; 
let userCounter = 0;

// פונקציה שמאפסת את הניקוד והמערך לתחילת המשחק
let initGame = () => {
    startBtn.style.display = "block";
    arrNum = [];
    playerScore = 0;
    userCounter = 0;
    gameScore = 0;
}

function startTheGame () {
    initGame();
    startBtn.style.display = "none";
    gameControler();
}

// פונקציה שיוצרת מספר רנדומלי בין 1 ל4
let createStep = () => {
    return Math.floor(Math.random() * 4) + 1;
}

// פונקציה שתשלוט במהלך של התור של המחשב
async function gameControler () {
    userTurn = false;
    let giveRandomNum = createStep();
    arrNum.push(giveRandomNum);
    await pcTurnNow();
    userTurn = true;
}

async function pcTurnNow () {
    userTurn = false;
    for (let i of arrNum) {
        await new Promise(resolve => setTimeout(resolve, 1000)); // הוספת עיכוב בין צעדים
        switch (i) {
            case 1:
                console.log("red");
                break;
            case 2:
                console.log("green");
                break;
            case 3:
                console.log("yellow");
                break;
            case 4:
                console.log("blue");
                break;
        }
    }
    userTurn = true;
}

function TheUserTurn (guess) {
    if (userTurn) {
        if (guessTrueOrFalse(guess, userCounter)) {
            userCounter++;
            if (userCounter >= arrNum.length) {
                gameScore++;
                userScoreInGame(gameScore);
                userCounter = 0;
                console.log("--------------------");
                gameControler();
            }
        } else {
            saveInLS(gameScore);
            // messageDiv.style.display = "block";
            startBtn.style.display = "block";
            theMessageContent(gameScore);
            initGame(); // איפוס המשחק גם במקרה של הפסד
            console.clear();
        }
    }
} 

// פונקציה שבודקת אם הלחיצה של המשתמש אכן תואמת למקום במערך
function guessTrueOrFalse (color, theIndex) {
    return color === arrNum[theIndex];
}

function userClickOnColor (event) {
    if (userTurn) {
        if (event.target.id === "red") {
            return TheUserTurn(1);
        }
        if (event.target.id === "green") {
            return TheUserTurn(2);
        }
        if (event.target.id === "yellow") {
            return TheUserTurn(3);
        }
        if (event.target.id === "blue") {
            return TheUserTurn(4);
        }
    }
}

// פונקציה שמעדכנת את השלב שבו המשתמש נמצא
function userScoreInGame(theScore) {
    spanScoreInGame.innerHTML = theScore;
}

// פונקציה שמעדכנת את ההודעה שבתוכה מופיע התוצאה ותוצאת השיא
function theMessageContent (score) {
    spanScore.innerHTML = score;
    let thehighScore = saveInLS();
    spanHighScore.innerHTML = thehighScore;
}

function saveInLS (lastScore) {
    let getFromLS = localStorage.getItem("highScoreSimon");
    if (!getFromLS || getFromLS < lastScore) {
        localStorage.setItem("highScoreSimon", lastScore);
        return lastScore;
    } else {
        return getFromLS;
    }
}

// ברירת המחדל ותחילת המשחק הוא שהתוצאה תתאפס , לכן הפונקציה הזו מופעלת באופן אוטומטי
initGame();

document.getElementById('red').addEventListener('click', userClickOnColor);
document.getElementById('green').addEventListener('click', userClickOnColor);
document.getElementById('yellow').addEventListener('click', userClickOnColor);
document.getElementById('blue').addEventListener('click', userClickOnColor);
let spanScoreInGame = document.getElementById('spanScoreInGame');
let spanScore = document.getElementById('spanScore');
let spanHighScore = document.getElementById('spanHighScore');

startBtn.addEventListener('click', startTheGame);
