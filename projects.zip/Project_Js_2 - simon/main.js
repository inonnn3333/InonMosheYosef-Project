let startBtn = document.getElementById('startGameBtn');
let massageDiv = document.getElementById('theMassage');


let playerScore = 0;
let arrNum = []; 
let NowUserTurn = false;
let highScore = 0;
let gameScore = 0; 
let userCounter = 0;


//! פונקציה שמאפסת את הניקוד והמערך לתחילת המשחק
let initGame = () => {
    startBtn.style.display = "block";
    // massageDiv.style.display = "none";
    arrNum = [];
    playerScore = 0;
    //TODO: להוסיף דיב שבו יתעדכן תוצאת המשחק ושלב המשחק, היינו שהכל יהיה 0.
}

function startTheGame () {
    initGame();
    startBtn.style.display = "none";
    gameControler();
}

//! פונקציה שיוצרת מספר רנדומלי בין 1 ל4
let createStep = () => {
    let randomNum = Math.floor(Math.random() * 4) + 1;
    return randomNum;
    // ?    1 - red
    // ?    2 - green
    // ?    3 - yellow
    // ?    4 - blue
}

//! פונקציה שתשלוט במהלך של התור של המחשב
async function gameControler () {
    // ווידוא שאכן התור הוא של המחשב ולא של השחקן
    NowUserTurn = false;
    // קורא לפונקציה שתיצור מספר רנדומלי
    let giveRandomNum = createStep();
    // המספר שנוצר יכנס למערך
    arrNum.push(giveRandomNum);
    // הצגת הצבעים למשתמש ע"י הפעלת הפונקציה הזאת
    await pcTurnNow()
    NowUserTurn = true;
    //TODO: להוסיף דיב שבו יתעדכן תוצאת המשחק ושלב המשחק.
}

async function pcTurnNow () {
    NowUserTurn = false;
    let someCounter = 0;
    for (let i of arrNum) {
        // הלולאה תרוץ אך ורק אם לא תהיה השוואה בין המשתנה לבין אורך המערך
        if (someCounter !== arrNum.length) {
            if (i == 1) {
                console.log("red");
            }
            if (i == 2) {
                console.log("green");
            }
            if (i == 3) {
                console.log("yellow");
            }
            if (i == 4) {
                console.log("blue");
            }
            //מוסיפים עוד מספר בכל איטרציה
            someCounter++;
        } 
    }
    NowUserTurn = true;
    // console.log(NowuserTurn);
}


function TheUserTurn (guess) {
    if (NowUserTurn) {
        if (guessTrueOrFalse(guess, userCounter)) {
            userCounter++
            //TODO: להוסיף דיב שבו יתעדכן תוצאת המשחק ושלב המשחק.
            if (userCounter >= arrNum.length) {
                gameScore++
                userScoreInGame(gameScore);
                userCounter = 0;
                console.log("--------------------");
                gameControler();
            }
        } else {
            saveInLS(gameScore);
            massageDiv.style.display = "block";
            startBtn.style.display = "block";
            theMassageContent(gameScore);
            gameScore = 0;
            userScoreInGame(gameScore);
            // console.clear();
        }
    }
} 

//! פונקציה שבודקת אם הלחיצה של המשתמש אכן תואמת למקום במערך
function guessTrueOrFalse (color, theIndex) {
    return color === arrNum[theIndex];
}

function userClickOnColor (event) {
    if (NowUserTurn) {
        if (event.target.id === "red") {
            // SOUND
            // console.log("red");
            return TheUserTurn(1);
        }
        if (event.target.id === "green") {
            // SOUND
            // console.log("green");
            return TheUserTurn(2);
        }
        if (event.target.id === "yellow") {
            // SOUND
            // console.log("yellow");
            return TheUserTurn(3);
        }
        if (event.target.id === "blue") {
            // SOUND
            // console.log("blue");
            return TheUserTurn(4);
        }
    }
}

//! הפונקציה מעדכנת את השלב שבו המשתמש נמצא
function userScoreInGame(theScore) {
    spanScoreInGame.innerHTML = theScore;
}

//! הפונקציה מעדכנת את ההודעה שבתוכה מופיע התוצאה ותוצאת השיא
function theMassageContent (score) {
    spanScore.innerHTML = score;
    let thehighScore = saveInLS();
    spanHighScore.innerHTML = thehighScore;
}

function saveInLS (lastScore) {
    let getFromLS = localStorage.getItem("highScoreSimon");
    if (!getFromLS) {
        localStorage.setItem("highScoreSimon", lastScore)
    } else {
        if(getFromLS >= lastScore) {
            return console.log(JSON.stringify(getFromLS));
        } else {
            localStorage.setItem("highScoreSimon", lastScore)
            return console.log(JSON.stringify(getFromLS));
        }
    }
}





//  ברירת המחדל ותחילת המחשק הוא שהתוצאה תתאפס , לכן הפונקציה הזו מופעלת באופן אוטומטי
initGame();

let redBtn = document.getElementById('red').addEventListener('click', userClickOnColor);
let greenBtn = document.getElementById('green').addEventListener('click', userClickOnColor);
let yellowBtn = document.getElementById('yellow').addEventListener('click', userClickOnColor);
let blueBtn = document.getElementById('blue').addEventListener('click', userClickOnColor);
let spanScoreInGame = document.getElementById('spanScoreInGame');
let spanScore = document.getElementById('spanScore');
let spanHighScore = document.getElementById('spanHighScore');




startBtn.addEventListener('click', startTheGame);