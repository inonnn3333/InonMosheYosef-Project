
// let arrRound = [];
// let gameCounter; // Game counter
// let userCounter;
// let isUserTurn = false
// let highScore = 0

// let endScore



// function initGame() {
//     gameCounter = userCounter = 0;
//     arrRound = [];
//     isUserTurn = false
//     renderRoundCounter()
// }

// // Function (B)
// async function playRound() {
//     document.getElementById("playModal").style.display = "none"
//     document.getElementById("endOfPlayModal").style.display = "none"
//     const newStep = createStep();
//     arrRound.push(newStep);

//     await pcTurn()
//     renderRoundCounter()
// }

// function userTurn(guess) {
//     if (isUserTurn) {
//         if (guessValidation(guess, userCounter)) {
//             userCounter++
//             renderRoundCounter()
//             if (userCounter >= arrRound.length) {
//                 userCounter = 0
//                 gameCounter++
//                 endScore = gameCounter
//                 renderRoundCounter()
//                 playRound()
//                 return
//             }

//         } else {
//             document.getElementById("endOfPlayModal").style.display = "block";
//             endScore = gameCounter
//             saveHighScore(calcHighScore())
//             initGame()
//             return
//         }

//     } else {
//         return
//     }
// }



// async function pcTurn() {
//     return new Promise(async (resolve) => {
//         isUserTurn = false
//         let arryIntervalCounter = 0
//         await delay(1000);

//         for (let i of arrRound) {
//             if (arryIntervalCounter !== arrRound.length) {
//                 if (i === 1) {
//                     await delay(20);
//                     await lightUpButton("green")
//                     await playSound(sounds.greenSound);
//                     await delay(20);
//                 }
//                 if (i === 2) {

//                     await delay(20);
//                     await lightUpButton("red")
//                     await playSound(sounds.redSound);
//                     await delay(20);

//                 }
//                 if (i === 3) {
//                     await delay(20);
//                     await lightUpButton("yellow")
//                     await playSound(sounds.yellowSound);
//                     await delay(20);
//                 }
//                 if (i === 4) {
//                     await delay(20);
//                     await lightUpButton("blue")
//                     await playSound(sounds.blueSound);
//                     await delay(20);
//                 }                
//                 arryIntervalCounter++

//             } else {
//                 isUserTurn = true
//                 resolve()
//             }
//         }
//         isUserTurn = true
//     })
// }


// //! פונקציה שמעדכנת בכל פעם את השלב במשחק ואת התוצאת שיא
// function renderRoundCounter() {
//     gameRoundDisplay.innerText = gameCounter
//     document.getElementById("correntScore").innerText = endScore
//     document.getElementById("higheScore").innerText = calcHighScore()
// }


// function calcHighScore() {
//     let savedScore = localStorage.getItem("highScore")
//     if (savedScore != 0 && savedScore > endScore) {
//         return savedScore
//     }
//     if (highScore > endScore) {
//         return highScore
//     } else {
//         return highScore = endScore
//     }
// }

// function createStep() {
//     return Math.floor(Math.random() * 4) + 1;
// }

// async function handleClickOnSimonBtn(event) {
//     if (isUserTurn) {
//         if (event.target.id === "green") {
//             sounds.greenSound.play()
//             return userTurn(1)
//         }
//         if (event.target.id === "red") {
//             sounds.redSound.play()
//             return userTurn(2)
//         }
//         if (event.target.id === "yellow") {
//             sounds.yellowSound.play()
//             return userTurn(3)
//         }
//         if (event.target.id === "blue") {
//             sounds.blueSound.play()
//             return userTurn(4)
//         }
//     } else {

// }
// }

// // arryIndex = [2, 4, 1, 1, 4]
// // userCounter = 4

// // green = 1
// // red = 4
// // blue = 2

// function guessValidation(number, arryIndex) {
//     return number === arrRound[arryIndex]
// }


// function delay(ms) {
//     return new Promise(resolve => setTimeout(resolve, ms));
// }


// async function lightUpButton(buttonId) {
//     const buttonElement = document.getElementById(buttonId);
//     buttonElement.classList.add(`${buttonId}On`);
//     await delay(150);
//     buttonElement.classList.remove(`${buttonId}On`);
//     await delay(150);
// }


// function saveHighScore(highScore) {
//     localStorage.setItem("highScore",highScore)
// }






// initGame();



